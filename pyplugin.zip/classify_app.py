#headline = input("Enter a news headline: ")
#print(headline)
print("hello world")